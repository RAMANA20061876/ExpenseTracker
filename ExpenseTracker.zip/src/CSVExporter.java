import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class CSVExporter {
    public static void exportToCSV(List<Expense> expenses, File file) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(file))) {
            writer.println("Date,Category,Amount,Note");
            for (Expense e : expenses) {
                writer.printf("%s,%s,%.2f,%s%n",
                        e.getDate(), e.getCategoryName(), e.getAmount(), e.getNote());
            }
        }
    }
}
