public class Expense {
    private int id;
    private String categoryName;
    private double amount;
    private String date;
    private String note;

    public Expense(int id, String categoryName, double amount, String date, String note) {
        this.id = id;
        this.categoryName = categoryName;
        this.amount = amount;
        this.date = date;
        this.note = note;
    }

    // Getters and Setters
}
